package com.example.data.repository

import com.example.data.local.AccountsDao
import com.example.data.local.BrandEntity
import com.example.data.local.CatalogDao
import com.example.data.local.CategoryEntity
import com.example.data.local.MerchantAccountEntity
import com.example.data.local.MerchantTransactionEntity
import com.example.data.local.ProductEntity
import com.example.data.local.ProductModelEntity
import com.example.data.local.SaleRecordEntity
import com.example.data.local.SalesDao
import com.example.data.local.SupplierAccountEntity
import com.example.data.local.SupplierTransactionEntity
import com.example.data.local.UserAccountEntity
import com.example.data.local.UserDao
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StoreRepository(
    private val userDao: UserDao,
    private val catalogDao: CatalogDao,
    private val salesDao: SalesDao,
    private val accountsDao: AccountsDao
) {
    // Users
    val allUsers: Flow<List<UserAccountEntity>> = userDao.getAllUsers()

    suspend fun getUserById(id: String): UserAccountEntity? = userDao.getUserById(id)

    suspend fun updatePin(id: String, newPin: String) {
        userDao.updatePin(id, newPin)
    }

    suspend fun updateCustomGreeting(id: String, greeting: String) {
        userDao.updateCustomGreeting(id, greeting)
    }

    // Catalog
    val allCategories: Flow<List<CategoryEntity>> = catalogDao.getAllCategories()
    val allBrands: Flow<List<BrandEntity>> = catalogDao.getAllBrands()
    val allProducts: Flow<List<ProductEntity>> = catalogDao.getAllProducts()
    val allModels: Flow<List<ProductModelEntity>> = catalogDao.getAllModels()

    fun getBrandsForCategory(catId: Long): Flow<List<BrandEntity>> =
        catalogDao.getBrandsForCategory(catId)

    fun getProductsForCategoryAndBrand(catId: Long, brandId: Long): Flow<List<ProductEntity>> =
        catalogDao.getProductsForCategoryAndBrand(catId, brandId)

    fun getModelsForProduct(productId: Long): Flow<List<ProductModelEntity>> =
        catalogDao.getModelsForProduct(productId)

    suspend fun getModelById(id: Long): ProductModelEntity? = catalogDao.getModelById(id)

    // Admin Catalog Mutators
    suspend fun addCategory(name: String, iconType: String = "APPLIANCE"): Long =
        catalogDao.insertCategory(CategoryEntity(name = name, iconType = iconType))

    suspend fun deleteCategory(id: Long) = catalogDao.deleteCategory(id)

    suspend fun addBrand(name: String, categoryId: Long): Long =
        catalogDao.insertBrand(BrandEntity(name = name, categoryId = categoryId))

    suspend fun deleteBrand(id: Long) = catalogDao.deleteBrand(id)

    suspend fun addProduct(
        name: String,
        categoryId: Long,
        categoryName: String,
        brandId: Long,
        brandName: String,
        description: String = ""
    ): Long = catalogDao.insertProduct(
        ProductEntity(
            name = name,
            categoryId = categoryId,
            categoryName = categoryName,
            brandId = brandId,
            brandName = brandName,
            description = description
        )
    )

    suspend fun deleteProduct(id: Long) = catalogDao.deleteProduct(id)

    suspend fun addModel(
        productId: Long,
        productName: String,
        brandName: String,
        categoryName: String,
        modelName: String,
        finalPrice: Double,
        minAllowedPrice: Double,
        stockQuantity: Int,
        code: String = ""
    ): Long = catalogDao.insertModel(
        ProductModelEntity(
            productId = productId,
            productName = productName,
            brandName = brandName,
            categoryName = categoryName,
            modelName = modelName,
            finalPrice = finalPrice,
            minAllowedPrice = minAllowedPrice,
            stockQuantity = stockQuantity,
            code = code
        )
    )

    suspend fun updateModel(model: ProductModelEntity) = catalogDao.updateModel(model)

    suspend fun deleteModel(id: Long) = catalogDao.deleteModel(id)

    suspend fun updateStock(modelId: Long, newStock: Int) =
        catalogDao.updateStock(modelId, newStock)

    // Sales
    val allSales: Flow<List<SaleRecordEntity>> = salesDao.getAllSales()

    suspend fun recordSale(
        modelId: Long,
        productName: String,
        modelName: String,
        categoryName: String,
        brandName: String,
        soldPrice: Double,
        minAllowedPrice: Double,
        originalFinalPrice: Double,
        quantity: Int,
        sellerId: String,
        sellerName: String,
        notes: String
    ): Result<Long> {
        // Enforce validation: cannot sell below minimum allowed price
        if (soldPrice < minAllowedPrice) {
            return Result.failure(
                IllegalArgumentException("سعر البيع لا يمكن أن يقل عن الحد الأدنى المسموح به ($minAllowedPrice ج.م)")
            )
        }

        // Deduct stock
        catalogDao.deductStock(modelId, quantity)

        // Record transaction
        val saleId = salesDao.insertSale(
            SaleRecordEntity(
                modelId = modelId,
                productName = productName,
                modelName = modelName,
                categoryName = categoryName,
                brandName = brandName,
                soldPrice = soldPrice,
                minAllowedPrice = minAllowedPrice,
                originalFinalPrice = originalFinalPrice,
                quantity = quantity,
                totalPrice = soldPrice * quantity,
                sellerId = sellerId,
                sellerName = sellerName,
                timestamp = System.currentTimeMillis(),
                notes = notes
            )
        )
        return Result.success(saleId)
    }

    // Accounts - Suppliers
    val allSuppliers: Flow<List<SupplierAccountEntity>> = accountsDao.getAllSuppliers()

    fun getSupplierTransactions(supplierId: Long): Flow<List<SupplierTransactionEntity>> =
        accountsDao.getTransactionsForSupplier(supplierId)

    suspend fun addSupplier(name: String, phone: String, initialPurchases: Double, notes: String): Long {
        return accountsDao.insertSupplier(
            SupplierAccountEntity(
                supplierName = name,
                phone = phone,
                totalPurchases = initialPurchases,
                totalPaid = 0.0,
                remainingBalance = initialPurchases,
                notes = notes
            )
        )
    }

    suspend fun addSupplierTransaction(supplierId: Long, type: String, amount: Double, notes: String) {
        val current = accountsDao.getSupplierById(supplierId) ?: return
        val newPurchases = if (type == "INVOICE") current.totalPurchases + amount else current.totalPurchases
        val newPaid = if (type == "PAYMENT") current.totalPaid + amount else current.totalPaid
        val newRemaining = newPurchases - newPaid

        accountsDao.updateSupplier(
            current.copy(
                totalPurchases = newPurchases,
                totalPaid = newPaid,
                remainingBalance = newRemaining
            )
        )
        accountsDao.insertSupplierTransaction(
            SupplierTransactionEntity(
                supplierId = supplierId,
                type = type,
                amount = amount,
                notes = notes,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateSupplierTransaction(
        transactionId: Long,
        newType: String,
        newAmount: Double,
        newNotes: String
    ) {
        val tx = accountsDao.getSupplierTransactionById(transactionId) ?: return
        val current = accountsDao.getSupplierById(tx.supplierId) ?: return

        var purchases = current.totalPurchases
        var paid = current.totalPaid

        // Revert old transaction effect
        if (tx.type == "INVOICE") {
            purchases -= tx.amount
        } else if (tx.type == "PAYMENT") {
            paid -= tx.amount
        }

        // Apply new transaction effect
        if (newType == "INVOICE") {
            purchases += newAmount
        } else if (newType == "PAYMENT") {
            paid += newAmount
        }

        val remaining = purchases - paid

        accountsDao.updateSupplier(
            current.copy(
                totalPurchases = maxOf(0.0, purchases),
                totalPaid = maxOf(0.0, paid),
                remainingBalance = remaining
            )
        )
        accountsDao.updateSupplierTransaction(
            tx.copy(
                type = newType,
                amount = newAmount,
                notes = newNotes
            )
        )
    }

    suspend fun deleteSupplierTransaction(transactionId: Long) {
        val tx = accountsDao.getSupplierTransactionById(transactionId) ?: return
        val current = accountsDao.getSupplierById(tx.supplierId) ?: return

        var purchases = current.totalPurchases
        var paid = current.totalPaid

        if (tx.type == "INVOICE") {
            purchases -= tx.amount
        } else if (tx.type == "PAYMENT") {
            paid -= tx.amount
        }

        val remaining = purchases - paid

        accountsDao.updateSupplier(
            current.copy(
                totalPurchases = maxOf(0.0, purchases),
                totalPaid = maxOf(0.0, paid),
                remainingBalance = remaining
            )
        )
        accountsDao.deleteSupplierTransaction(transactionId)
    }

    suspend fun deleteSupplier(supplierId: Long) {
        accountsDao.deleteSupplierTransactionsBySupplier(supplierId)
        accountsDao.deleteSupplier(supplierId)
    }

    // Accounts - Merchants (تجار بالأجل)
    val allMerchants: Flow<List<MerchantAccountEntity>> = accountsDao.getAllMerchants()

    fun getMerchantTransactions(merchantId: Long): Flow<List<MerchantTransactionEntity>> =
        accountsDao.getTransactionsForMerchant(merchantId)

    suspend fun addMerchant(name: String, phone: String, initialDelivered: Double, notes: String): Long {
        return accountsDao.insertMerchant(
            MerchantAccountEntity(
                merchantName = name,
                phone = phone,
                totalGoodsDelivered = initialDelivered,
                totalCollected = 0.0,
                remainingDueToMe = initialDelivered,
                notes = notes
            )
        )
    }

    suspend fun addMerchantTransaction(merchantId: Long, type: String, amount: Double, notes: String) {
        val current = accountsDao.getMerchantById(merchantId) ?: return
        val newDelivered = if (type == "GOODS_DELIVERED") current.totalGoodsDelivered + amount else current.totalGoodsDelivered
        val newCollected = if (type == "COLLECTION") current.totalCollected + amount else current.totalCollected
        val newRemaining = newDelivered - newCollected

        accountsDao.updateMerchant(
            current.copy(
                totalGoodsDelivered = newDelivered,
                totalCollected = newCollected,
                remainingDueToMe = newRemaining
            )
        )
        accountsDao.insertMerchantTransaction(
            MerchantTransactionEntity(
                merchantId = merchantId,
                type = type,
                amount = amount,
                notes = notes,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateMerchantTransaction(
        transactionId: Long,
        newType: String,
        newAmount: Double,
        newNotes: String
    ) {
        val tx = accountsDao.getMerchantTransactionById(transactionId) ?: return
        val current = accountsDao.getMerchantById(tx.merchantId) ?: return

        var delivered = current.totalGoodsDelivered
        var collected = current.totalCollected

        // Revert old transaction effect
        if (tx.type == "GOODS_DELIVERED") {
            delivered -= tx.amount
        } else if (tx.type == "COLLECTION") {
            collected -= tx.amount
        }

        // Apply new transaction effect
        if (newType == "GOODS_DELIVERED") {
            delivered += newAmount
        } else if (newType == "COLLECTION") {
            collected += newAmount
        }

        val remaining = delivered - collected

        accountsDao.updateMerchant(
            current.copy(
                totalGoodsDelivered = maxOf(0.0, delivered),
                totalCollected = maxOf(0.0, collected),
                remainingDueToMe = remaining
            )
        )
        accountsDao.updateMerchantTransaction(
            tx.copy(
                type = newType,
                amount = newAmount,
                notes = newNotes
            )
        )
    }

    suspend fun deleteMerchantTransaction(transactionId: Long) {
        val tx = accountsDao.getMerchantTransactionById(transactionId) ?: return
        val current = accountsDao.getMerchantById(tx.merchantId) ?: return

        var delivered = current.totalGoodsDelivered
        var collected = current.totalCollected

        if (tx.type == "GOODS_DELIVERED") {
            delivered -= tx.amount
        } else if (tx.type == "COLLECTION") {
            collected -= tx.amount
        }

        val remaining = delivered - collected

        accountsDao.updateMerchant(
            current.copy(
                totalGoodsDelivered = maxOf(0.0, delivered),
                totalCollected = maxOf(0.0, collected),
                remainingDueToMe = remaining
            )
        )
        accountsDao.deleteMerchantTransaction(transactionId)
    }

    suspend fun deleteMerchant(merchantId: Long) {
        accountsDao.deleteMerchantTransactionsByMerchant(merchantId)
        accountsDao.deleteMerchant(merchantId)
    }

    // Backup & Export (CSV format)
    fun buildCsvExport(
        models: List<ProductModelEntity>,
        sales: List<SaleRecordEntity>,
        suppliers: List<SupplierAccountEntity>,
        merchants: List<MerchantAccountEntity>
    ): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val sb = StringBuilder()

        sb.append("=== البشيري للأجهزة الكهربائية - تقرير النسخة الاحتياطية الشاملة ===\n")
        sb.append("تاريخ التصدير: ").append(dateFormat.format(Date())).append("\n\n")

        // 1. Inventory & Products
        sb.append("--- 1. كشف المنتجات والموديلات والمخزون ---\n")
        sb.append("القسم,الشركة,اسم المنتج,الموديل / المواصفة,كود الموديل,الكمية بالمخزن,سعر البيع النهائي,الحد الأدنى للبيع\n")
        models.forEach { m ->
            sb.append("\"${m.categoryName}\",\"${m.brandName}\",\"${m.productName}\",\"${m.modelName}\",\"${m.code}\",${m.stockQuantity},${m.finalPrice},${m.minAllowedPrice}\n")
        }
        sb.append("\n")

        // 2. Sales Log
        sb.append("--- 2. سجل عمليات البيع ---\n")
        sb.append("التاريخ والوقت,اسم البائع,المنتج,الموديل,الكمية,سعر القطعة الفعلي,إجمالي العملية,ملاحظات\n")
        sales.forEach { s ->
            val dateStr = dateFormat.format(Date(s.timestamp))
            sb.append("\"$dateStr\",\"${s.sellerName}\",\"${s.productName}\",\"${s.modelName}\",${s.quantity},${s.soldPrice},${s.totalPrice},\"${s.notes}\"\n")
        }
        sb.append("\n")

        // 3. Supplier Accounts
        sb.append("--- 3. كشوف حسابات الموردين ---\n")
        sb.append("اسم الشركة الموردة,رقم الهاتف,إجمالي المشتريات,إجمالي المدفوع,الباقي المستحق للمورد,ملاحظات\n")
        suppliers.forEach { sup ->
            sb.append("\"${sup.supplierName}\",\"${sup.phone}\",${sup.totalPurchases},${sup.totalPaid},${sup.remainingBalance},\"${sup.notes}\"\n")
        }
        sb.append("\n")

        // 4. Merchant Credit Accounts
        sb.append("--- 4. كشوف حسابات تجار الأجل ---\n")
        sb.append("اسم التاجر,رقم الهاتف,إجمالي البضاعة المسلمة,إجمالي المحصل,الباقي المستحق لي,ملاحظات\n")
        merchants.forEach { m ->
            sb.append("\"${m.merchantName}\",\"${m.phone}\",${m.totalGoodsDelivered},${m.totalCollected},${m.remainingDueToMe},\"${m.notes}\"\n")
        }

        return sb.toString()
    }
}
