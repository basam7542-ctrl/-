package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy & Gold Brand Palette for "البشيري للأجهزة الكهربائية"
val NavyDarkBackground = Color(0xFF090E1A)
val NavySurface = Color(0xFF10192A)
val NavySurfaceVariant = Color(0xFF1B283F)
val NavySurfaceElevated = Color(0xFF24334E)
val NavyCardBorder = Color(0xFF2E4166)

val GoldPrimary = Color(0xFFD4AF37)
val GoldSecondary = Color(0xFFF3C64F)
val GoldLight = Color(0xFFFDE68A)
val GoldDark = Color(0xFF997A15)
val GoldContainer = Color(0xFF2E2409)

val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val TextDark = Color(0xFF0B132B)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
